import metamaskImg  from "./metamask.png";
import topSellerImg from "./top-seller-img.png";
import nftImg1 from "./nft-img1.png"
import NFTNews1 from "./nft-news-1.png";

export { metamaskImg, topSellerImg, nftImg1, NFTNews1 };