import Footer from 'Components/Footer/Footer'
import Navbar from 'Components/Navbar/Navbar'
import Rewards from 'Components/Rewards/Rewards'
import React from 'react'

function Reward() {
  return (
    <>
   
       <Navbar/>
        <Rewards/>


    <Footer/>
    </>
  )
}

export default Reward