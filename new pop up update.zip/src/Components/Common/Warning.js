import React from 'react'

function Warning() {
  return (
    <>       <div className="warning-box">
    <h2>
      Cryptocurrency may be unregulated in your jurisdiction. The value of
      cryptocurrencies may go down as well as up. Profits may be subject
      to capital gains or other taxes applicable in your jurisdiction.
    </h2>
  </div></>
  )
}

export default Warning